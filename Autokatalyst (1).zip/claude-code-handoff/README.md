# Autokatalyst V5 — publish to GitHub

Task for Claude Code: commit the contents of `site/` to the Autokatalyst prototype
repository and open a pull request.

- Repository: https://github.com/nusakutnjak-sys/Autokatalyst-Prototype.git
- Default branch: `main`
- The repository is currently **empty** — this is the initial commit.

## What to do

1. Clone the repository.
2. Copy everything inside `site/` to the repository root, preserving the folder
   structure (`index.html` and `Placeholder page.html` sit at the root; `v5/`,
   `v2/` and `assets/` sit beside them).
3. Commit on a branch named `v5-prototype` and push it, then open a pull request
   against `main`. Commit message: "Add V5 prototype".
4. After the PR is merged, enable GitHub Pages on `main` / root so the prototype
   is served at the Pages URL.

## What this is

A static HTML/CSS/JS prototype of the Autokatalyst homepage. There is **no build
step and no package manager** — the pages load their stylesheets and scripts with
plain relative paths, so the repository root can be served directly.

Do not restructure, bundle, minify, reformat or "modernise" these files. They are
the deliverable exactly as they are; the only change needed is putting them in the
repository.

## Contents

| Path | What it is |
| --- | --- |
| `index.html` | The homepage (hero, audience section, work, case studies, closing CTA, footer) |
| `Placeholder page.html` | The stand-in page every navigation link opens, so page transitions can be seen |
| `v5/styles.css` | All page styling — design tokens, grid, every section |
| `v5/motion-specialize.js` | V5-specific motion: audience hover panel, section parallax, hero band entrance, CTA domino chain |
| `v2/motion.css`, `v2/main.js`, `v2/motion/*.js` | The shared motion system — tokens, easing curves, reusable modules, hero entrance, scroll-driven dominoes, card stack, page transitions |
| `assets/` | Logo, case-study imagery, audience imagery, the CTA domino graphics |

External dependencies are loaded from a CDN inside the HTML (GSAP with ScrollTrigger
and CustomEase, Barba, Lenis). Nothing needs installing.
